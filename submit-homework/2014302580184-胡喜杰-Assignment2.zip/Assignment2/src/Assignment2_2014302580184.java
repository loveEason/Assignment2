import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.regex.*;

/**
 * 要求：请爬取任意学校任意学院中某一位老师的个人主页及资料（网页上要有其邮箱及电话号码），
 * 使用JSoup对所爬取的HTML代码进行解析，并用正则表达式提取出其邮箱和电话号码，
 * 写入到一个txt文档中，该txt文档需要包括的信息有：教师姓名，简介，研究方向，邮箱及电话号码。
 *
 * 学号：2014302580184
 * 姓名：胡喜杰
 * 时间：2015.10.20
 */
public class Assignment2_2014302580184 {
    public static void main(String[] args) {
     //爬取老师个人主页
        try{
            TeacherCrawler();
        }catch (Exception e){
            e.printStackTrace();
        }

        //使用JSoup对所爬取的HTML代码进行解析，并用正则表达式提取出其邮箱和电话号码
        try{
            JsoupAnalyse("teacherPerson.html","./teacherPerson.txt");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //爬取老师个人主页
    public static void TeacherCrawler() throws Exception{
        String url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Hu%20Bin";
        HttpRequest request = HttpRequest.get(url);
        File fName = new File("teacherPerson.html");
        if (fName.exists()) {}
        else request.receive(fName);
    }

    //使用JSoup对所爬取的HTML代码进行解析，并用正则表达式提取出其邮箱和电话号码
    public static void JsoupAnalyse(String htmlName,String txtName) throws Exception{

        //创建输出文件
        File output = new File(txtName);
        FileWriter fw = new FileWriter(output);
        BufferedWriter bufw = new BufferedWriter(fw);

        //从文件中加载html文档
        File input = new File(htmlName);
        Document doc = Jsoup.parse(input,"UTF-8");

        //解析并提取HTML元素
        //提取名字并输入
        Element name = doc.select("h1").get(0);
        bufw.write("姓名：");
        bufw.write(name.text());
        bufw.newLine();

        //提取研究方向并输入
        Elements contents2 = doc.select("p");
        Pattern pattern = Pattern.compile("研究方向+.+[\u4E00-\u9FA5]+\\s");
        Matcher researchDirection = pattern.matcher(contents2.get(0).text());
        while(researchDirection.find())
        {
            bufw.write(researchDirection.group());
        }
        bufw.newLine();

        //提取电话号码并输入
        Pattern pattern1 = Pattern.compile("联系电话+.+[0-9]+\\s");
        Matcher phoneNumber = pattern1.matcher(contents2.get(0).text());
        while(phoneNumber.find()) {
            bufw.write(phoneNumber.group());
        }
        bufw.newLine();

        //提取邮箱并输入
        Pattern pattern2 = Pattern.compile("Email+.+\\w");
        Matcher mailbox = pattern2.matcher(contents2.get(0).text());
        while(mailbox.find()) {
            bufw.write(mailbox.group());
        }
        bufw.newLine();

        //提取简介并输入
        Elements contents = doc.select("p font");
        bufw.write("简介：");
        bufw.write(contents.get(1).text());
        bufw.newLine();

        bufw.close();
        fw.close();
    }
}
